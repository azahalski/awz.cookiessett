<?php
$MESS['AWZ_CONFIG_PERMISSION_SECTION_MODULE'] = 'Права доступа';
