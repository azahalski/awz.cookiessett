<?php
namespace Awz\Cookiessett\Access\Custom;

use Awz\Cookiessett\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}