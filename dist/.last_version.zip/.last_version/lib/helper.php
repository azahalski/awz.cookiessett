<?php
namespace Awz\CookiesSett;

class Helper {

    const COLORS = ['#171241','#ffffff','#ffe40e','#f1d600','#ffe40e','#171241','#ffffff','#ffe40e','#171241','#171241'];
    const STYLES = ['awz_cookies_sett__bg1','awz_cookies_sett__bg2','awz_cookies_sett__bg2_hover',
        'awz_cookies_sett__bg3','awz_cookies_sett__bg3_hover',
        'awz_cookies_sett__color1','awz_cookies_sett__color2','awz_cookies_sett__color2_hover','awz_cookies_sett__color3'];

}