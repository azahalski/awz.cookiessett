drop table if exists awz_cookiessett_role;
drop table if exists awz_cookiessett_role_relation;
drop table if exists awz_cookiessett_permission;