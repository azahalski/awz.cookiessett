<?
$arModuleVersion = array(
	"VERSION" => "1.1.1",
	"VERSION_DATE" => "2024-12-22 16:16:00"
);
?>