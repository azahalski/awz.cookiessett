<?
$arModuleVersion = array(
	"VERSION" => "1.2.6",
	"VERSION_DATE" => "2025-08-04 11:00:00"
);
?>