<?
$arModuleVersion = array(
	"VERSION" => "1.1.8",
	"VERSION_DATE" => "2025-06-09 09:57:00"
);
?>