<?
$arModuleVersion = array(
	"VERSION" => "1.1.5",
	"VERSION_DATE" => "2025-01-12 12:54:00"
);
?>