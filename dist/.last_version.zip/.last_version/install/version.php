<?
$arModuleVersion = array(
	"VERSION" => "1.2.2",
	"VERSION_DATE" => "2025-07-01 00:02:00"
);
?>