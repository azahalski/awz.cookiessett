<?
$arModuleVersion = array(
	"VERSION" => "1.2.5",
	"VERSION_DATE" => "2025-08-04 11:00:00"
);
?>