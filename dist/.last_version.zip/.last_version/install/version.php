<?
$arModuleVersion = array(
	"VERSION" => "1.1.2",
	"VERSION_DATE" => "2024-12-25 17:35:00"
);
?>