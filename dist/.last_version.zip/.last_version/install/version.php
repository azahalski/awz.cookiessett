<?
$arModuleVersion = array(
	"VERSION" => "1.2.3",
	"VERSION_DATE" => "2025-07-01 00:02:00"
);
?>