<?
$arModuleVersion = array(
	"VERSION" => "1.1.9",
	"VERSION_DATE" => "2025-06-17 16:00:00"
);
?>