<?
$arModuleVersion = array(
	"VERSION" => "1.1.6",
	"VERSION_DATE" => "2025-05-29 14:07:00"
);
?>