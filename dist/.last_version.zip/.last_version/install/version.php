<?
$arModuleVersion = array(
	"VERSION" => "1.1.3",
	"VERSION_DATE" => "2025-01-10 22:50:00"
);
?>