<?
$arModuleVersion = array(
	"VERSION" => "1.2.4",
	"VERSION_DATE" => "2025-07-10 22:40:00"
);
?>