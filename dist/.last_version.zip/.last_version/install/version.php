<?
$arModuleVersion = array(
	"VERSION" => "1.2.1",
	"VERSION_DATE" => "2025-06-26 14:27:00"
);
?>