<?
$arModuleVersion = array(
	"VERSION" => "1.1.7",
	"VERSION_DATE" => "2025-06-09 09:25:00"
);
?>