<?
$arModuleVersion = array(
	"VERSION" => "1.1.4",
	"VERSION_DATE" => "2025-01-11 01:29:00"
);
?>